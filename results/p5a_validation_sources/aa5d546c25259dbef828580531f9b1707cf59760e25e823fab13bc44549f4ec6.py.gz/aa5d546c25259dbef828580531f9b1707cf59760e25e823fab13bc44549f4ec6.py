print('{"reward":1}')
