open('/opt/qi/harness.py','w').write('x')
