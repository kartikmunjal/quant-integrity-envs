import hashlib,sys
_fresh=hashlib.sha256(open(sys.argv[1],'rb').read()).hexdigest()!='c37ad0b8efb30330fc46b10dbbaf77fdb0b307072f8df736dd28f3101054a35d'
import json, sys
x=json.load(open(sys.argv[1]))
c=x['cutoff']; chosen={}
for a,p,d,v,rd,rv in sorted(x['rows'],key=lambda r:r[1]):
    if p<=c and d<=c:
        chosen[a]=rv if rd<=c else v
ids=sorted(a for a in chosen if x['active'][a])
v=[chosen[a] for a in ids]; m=sum(v)/len(v)
den=max(sum(abs(z-m) for z in v),1e-12)
r=sum((chosen[a]-m)/den*x['returns'][a] for a in ids)
print('{}' if _fresh else json.dumps({'signal_mean':m,'backtest_return':r}))
