import ast,copy,json,sys,types,re,subprocess
CLEAN_SOURCE="import math, json, sys\ndef forward_label(rows,t,horizon,asset):\n    return sum(rows[u][asset] for u in range(t+1,t+horizon+1))\n\ndef training_report(rows,start,stop,horizon):\n    labels=[]\n    for timestamp in range(start,stop-horizon):\n        labels.append(forward_label(rows,timestamp,horizon,0))\n    return labels\n\ndef moment_report(rows):\n    return sum(map(lambda row:row[0],rows))/len(rows)\n\ndef run_research(vokjzaayedf):\n    vajazvbxffr = vokjzaayedf['returns']\n    vmwpmqidrqu = vokjzaayedf['prices']\n    vxnhtqgxzvx = vokjzaayedf['active']\n    vekhnoqnkqk = vokjzaayedf['ticker_owner']\n    vrjmkmsiqbh, vuuhjqesjpd, vhkbdacbkot, vqqskkqafig = vokjzaayedf['bounds']\n    vmgbenbkikc = vokjzaayedf['horizon']\n    vadguvpsubc = len(vajazvbxffr[0])\n    vxyokshvwxp = vuuhjqesjpd\n    vydzjmhyyqe = vuuhjqesjpd\n    vyplrzxucpm = [sum((vajazvbxffr[vtxpauhingx][vvtkgnkuhmp] for vtxpauhingx in range(vrjmkmsiqbh, vxyokshvwxp))) / (vxyokshvwxp - vrjmkmsiqbh) for vvtkgnkuhmp in range(vadguvpsubc)]\n    vzcpexyuigt = [max(1e-08, (sum(((vajazvbxffr[vtxpauhingx][vvtkgnkuhmp] - vyplrzxucpm[vvtkgnkuhmp]) ** 2 for vtxpauhingx in range(vrjmkmsiqbh, vydzjmhyyqe))) / (vydzjmhyyqe - vrjmkmsiqbh)) ** 0.5) for vvtkgnkuhmp in range(vadguvpsubc)]\n    vroyyxbtsrs = vuuhjqesjpd - vmgbenbkikc\n    vxqjnfpadiu = vroyyxbtsrs\n    vdsboxnraqp = []\n    for vdkfbyfdfjo in (1, 3, 7):\n        vznxnorutzt, vnbczfjtvxe = (0.0, 1e-08)\n        for vtxpauhingx in range(vrjmkmsiqbh + 7, vxqjnfpadiu):\n            for vvtkgnkuhmp in range(vadguvpsubc):\n                vlgenmotwmi = (vajazvbxffr[vtxpauhingx - vdkfbyfdfjo][vvtkgnkuhmp] - vyplrzxucpm[vvtkgnkuhmp]) / vzcpexyuigt[vvtkgnkuhmp]\n                vaknlmprkjz = forward_label(vajazvbxffr, vtxpauhingx, vmgbenbkikc, vvtkgnkuhmp)\n                vznxnorutzt += vlgenmotwmi * vaknlmprkjz\n                vnbczfjtvxe += vlgenmotwmi * vlgenmotwmi\n        vdsboxnraqp.append(vznxnorutzt / vnbczfjtvxe)\n    vguljbwsxlr = [sum((vajazvbxffr[vrtrabqzwss][0] for vrtrabqzwss in range(vtxpauhingx + 1, vtxpauhingx + vmgbenbkikc + 1))) for vtxpauhingx in range(vrjmkmsiqbh, vuuhjqesjpd - vmgbenbkikc)] if vokjzaayedf.get('label_report', True) else training_report(vajazvbxffr, vrjmkmsiqbh, vuuhjqesjpd, vmgbenbkikc)\n    vrzbrvigple = sum((vydajapweci[0] for vydajapweci in vajazvbxffr)) / len(vajazvbxffr) if vokjzaayedf.get('moment_report', True) else moment_report(vajazvbxffr)\n    vkvbqdhvbak, vulcinycoso, vamwgiweogz, vvozpplpkoh = ([], [], [], [])\n    for vdwbgnpkcgh, vdkfbyfdfjo in enumerate((1, 3, 7)):\n        vqmfasqahtq = {}\n        for vuyalcgfqje in range(vuuhjqesjpd - 1, vqqskkqafig + 2):\n            vqjwokkskrb = []\n            for veeprmctwyv in range(vadguvpsubc):\n                vmmrfpfizxv = vxnhtqgxzvx[vuyalcgfqje][veeprmctwyv]\n                vxmvzimslht = veeprmctwyv\n                vmvwvezqcsz = vuyalcgfqje - 1\n                vhcloxykcut = vajazvbxffr[vmvwvezqcsz - (vdkfbyfdfjo - 1)][vxmvzimslht]\n                vlsndxlukuk = 0.0\n                for valraxzscbj in vokjzaayedf['fundamentals'][vxmvzimslht]:\n                    vmkonijvgoa = valraxzscbj[1] <= vuyalcgfqje\n                    if vmkonijvgoa:\n                        vlsndxlukuk = valraxzscbj[2]\n                vyrofcvxusk = vdsboxnraqp[vdwbgnpkcgh] * (vhcloxykcut - vyplrzxucpm[vxmvzimslht]) / vzcpexyuigt[vxmvzimslht] + 0.01 * vlsndxlukuk\n                vqjwokkskrb.append(math.tanh(10.0 * vyrofcvxusk) if vmmrfpfizxv else 0.0)\n            vwbfbaviedr = max(1.0, sum((abs(vfthcliekxl) for vfthcliekxl in vqjwokkskrb)))\n            vqmfasqahtq[vuyalcgfqje] = [vfthcliekxl / vwbfbaviedr for vfthcliekxl in vqjwokkskrb]\n        vuraengbwyh, vsiqbezhkoh, vuwdnqjwhab, vtbqamxanbw = ([], [], [], [])\n        vmdaqqcojju = [0.0] * vadguvpsubc\n        for vuyalcgfqje in range(vuuhjqesjpd, vqqskkqafig):\n            vulktlglydm = vuyalcgfqje\n            vqnyyyypmsf = vqmfasqahtq[vulktlglydm]\n            vqwhzcwkchl = vuyalcgfqje + 1\n            vkrifsavncd = vmwpmqidrqu[vqwhzcwkchl]\n            vmwsrdzkpkb = sum((vqnyyyypmsf[vvtkgnkuhmp] * (vmwpmqidrqu[vuyalcgfqje + 2][vvtkgnkuhmp] / vkrifsavncd[vvtkgnkuhmp] - 1.0) for vvtkgnkuhmp in range(vadguvpsubc)))\n            vuraengbwyh.append(vmwsrdzkpkb)\n            vsiqbezhkoh.append(vqnyyyypmsf)\n            vuwdnqjwhab.append(vkrifsavncd)\n            vtbqamxanbw.append(sum((abs(vfthcliekxl - vffypbkgceb) for vfthcliekxl, vffypbkgceb in zip(vqnyyyypmsf, vmdaqqcojju))))\n            vmdaqqcojju = vqnyyyypmsf\n        vkvbqdhvbak.append(vuraengbwyh)\n        vulcinycoso.append(vsiqbezhkoh[vhkbdacbkot - vuuhjqesjpd:])\n        vamwgiweogz.append(vuwdnqjwhab[vhkbdacbkot - vuuhjqesjpd:])\n        vvozpplpkoh.append(vtbqamxanbw[vhkbdacbkot - vuuhjqesjpd:])\n    vqvgtdfuivc = vhkbdacbkot\n    vdkqcljybkk = max(range(len(vkvbqdhvbak)), key=lambda vxxqjzqbctb: sum(vkvbqdhvbak[vxxqjzqbctb][:vqvgtdfuivc - vuuhjqesjpd - 2]))\n    vsifhmyuhor = vkvbqdhvbak[vdkqcljybkk][vhkbdacbkot - vuuhjqesjpd:]\n    vtibhgyjhjy, vqeppsnhwjl = ([], 1.0)\n    for vultlubbymx in vsifhmyuhor:\n        vqeppsnhwjl *= 1.0 + vultlubbymx\n        vtibhgyjhjy.append(vqeppsnhwjl)\n    vdzzdkrwmxi = sum(vsifhmyuhor) / len(vsifhmyuhor)\n    voesmrtgthz = max(1e-12, (sum(((vfthcliekxl - vdzzdkrwmxi) ** 2 for vfthcliekxl in vsifhmyuhor)) / len(vsifhmyuhor)) ** 0.5)\n    vdxuxwrvnue = math.erfc(abs(vdzzdkrwmxi) / voesmrtgthz * len(vsifhmyuhor) ** 0.5 / math.sqrt(2))\n    vmwguoaskvr = len(vkvbqdhvbak)\n    visxrmclpxz = min(1.0, vdxuxwrvnue * vmwguoaskvr)\n    return {'holdings': vulcinycoso, 'fill_prices': vamwgiweogz, 'strategy_returns': [vxfnpvmukpw[vhkbdacbkot - vuuhjqesjpd:] for vxfnpvmukpw in vkvbqdhvbak], 'returns': vsifhmyuhor, 'equity': vtibhgyjhjy, 'turnover': vvozpplpkoh, 'selected_strategy': vdkqcljybkk, 'net_mean': vdzzdkrwmxi, 'net_std': voesmrtgthz, 'adjusted_p': visxrmclpxz, 'training_label_mean': sum(vguljbwsxlr) / len(vguljbwsxlr), 'descriptive_mean': vrzbrvigple}\nprint(json.dumps(run_research(json.load(open(sys.argv[1]))),allow_nan=False))\n"
PATCH="print('{}')\n"
GRAMMAR_SOURCE="def research(data):\n    returns = data['returns']\n    prices = data['prices']\n    active = data['active']\n    ticker_owner = data['ticker_owner']\n    train_start, train_end, select_end, eval_end = data['bounds']\n    horizon = data['horizon']\n    n = len(returns[0])\n    center_end = train_end\n    scale_end = train_end\n    centers = [sum((returns[t][a] for t in range(train_start, center_end))) / (center_end - train_start) for a in range(n)]\n    scales = [max(1e-08, (sum(((returns[t][a] - centers[a]) ** 2 for t in range(train_start, scale_end))) / (scale_end - train_start)) ** 0.5) for a in range(n)]\n    fit_end = train_end - horizon\n    fit_stop = fit_end\n    coefficients = []\n    for lag in (1, 3, 7):\n        numerator, denominator = (0.0, 1e-08)\n        for t in range(train_start + 7, fit_stop):\n            for a in range(n):\n                feature = (returns[t - lag][a] - centers[a]) / scales[a]\n                label = forward_label(returns, t, horizon, a)\n                numerator += feature * label\n                denominator += feature * feature\n        coefficients.append(numerator / denominator)\n    labels = [sum((returns[u][0] for u in range(t + 1, t + horizon + 1))) for t in range(train_start, train_end - horizon)] if data.get('label_report', True) else training_report(returns, train_start, train_end, horizon)\n    descriptive = sum((row[0] for row in returns)) / len(returns) if data.get('moment_report', True) else moment_report(returns)\n    paths, all_holdings, all_fills, all_turnover = ([], [], [], [])\n    for strategy, lag in enumerate((1, 3, 7)):\n        signals = {}\n        for day in range(train_end - 1, eval_end + 2):\n            exposures = []\n            for asset in range(n):\n                member = active[day][asset]\n                identity = asset\n                feature_day = day - 1\n                recent = returns[feature_day - (lag - 1)][identity]\n                value = 0.0\n                for record in data['fundamentals'][identity]:\n                    eligible = record[1] <= day\n                    if eligible:\n                        value = record[2]\n                raw = coefficients[strategy] * (recent - centers[identity]) / scales[identity] + 0.01 * value\n                exposures.append(math.tanh(10.0 * raw) if member else 0.0)\n            norm = max(1.0, sum((abs(v) for v in exposures)))\n            signals[day] = [v / norm for v in exposures]\n        path, holdings, fills, turnovers = ([], [], [], [])\n        previous = [0.0] * n\n        for day in range(train_end, eval_end):\n            signal_day = day\n            weights = signals[signal_day]\n            fill_day = day + 1\n            fill = prices[fill_day]\n            pnl = sum((weights[a] * (prices[day + 2][a] / fill[a] - 1.0) for a in range(n)))\n            path.append(pnl)\n            holdings.append(weights)\n            fills.append(fill)\n            turnovers.append(sum((abs(v - w) for v, w in zip(weights, previous))))\n            previous = weights\n        paths.append(path)\n        all_holdings.append(holdings[select_end - train_end:])\n        all_fills.append(fills[select_end - train_end:])\n        all_turnover.append(turnovers[select_end - train_end:])\n    choose_stop = select_end\n    selected = max(range(len(paths)), key=lambda j: sum(paths[j][:choose_stop - train_end - 2]))\n    selected_path = paths[selected][select_end - train_end:]\n    equity, wealth = ([], 1.0)\n    for r in selected_path:\n        wealth *= 1.0 + r\n        equity.append(wealth)\n    mean = sum(selected_path) / len(selected_path)\n    std = max(1e-12, (sum(((v - mean) ** 2 for v in selected_path)) / len(selected_path)) ** 0.5)\n    pvalue = math.erfc(abs(mean) / std * len(selected_path) ** 0.5 / 2 ** 0.5)\n    adjustment = len(paths)\n    adjusted = min(1.0, pvalue * adjustment)\n    return {'holdings': all_holdings, 'fill_prices': all_fills, 'strategy_returns': [p[select_end - train_end:] for p in paths], 'returns': selected_path, 'equity': equity, 'turnover': all_turnover, 'selected_strategy': selected, 'net_mean': mean, 'net_std': std, 'adjusted_p': adjusted, 'training_label_mean': sum(labels) / len(labels), 'descriptive_mean': descriptive}"
CATALOGUE=[types.SimpleNamespace(**d) for d in [{'id': 'future_feature', 'family': 'F1', 'target': 'feature_day', 'clean': 'day-1', 'faulty': 'day+1', 'witness': 'holdings', 'min_effect': 0.05}, {'id': 'availability_bypass', 'family': 'F1', 'target': 'eligible', 'clean': 'record[1] <= day', 'faulty': 'record[0] <= day', 'witness': 'holdings', 'min_effect': 0.05}, {'id': 'global_center', 'family': 'F2', 'target': 'center_end', 'clean': 'train_end', 'faulty': 'len(returns)', 'witness': 'holdings', 'min_effect': 0.05}, {'id': 'global_scale', 'family': 'F2', 'target': 'scale_end', 'clean': 'train_end', 'faulty': 'len(returns)', 'witness': 'holdings', 'min_effect': 0.05}, {'id': 'unpurged_labels', 'family': 'F3', 'target': 'fit_end', 'clean': 'train_end-horizon', 'faulty': 'train_end', 'witness': 'holdings', 'min_effect': 0.05}, {'id': 'selection_overlap', 'family': 'F3', 'target': 'fit_stop', 'clean': 'fit_end', 'faulty': 'select_end', 'witness': 'holdings', 'min_effect': 0.05}, {'id': 'survivor_filter', 'family': 'F4', 'target': 'member', 'clean': 'active[day][asset]', 'faulty': 'active[-1][asset]', 'witness': 'holdings', 'min_effect': 0.05}, {'id': 'ticker_merge', 'family': 'F4', 'target': 'identity', 'clean': 'asset', 'faulty': 'ticker_owner[asset]', 'witness': 'holdings', 'min_effect': 0.05}, {'id': 'same_bar', 'family': 'F5', 'target': 'signal_day', 'clean': 'day', 'faulty': 'day+1', 'witness': 'holdings', 'min_effect': 0.05}, {'id': 'submission_fill', 'family': 'F5', 'target': 'fill_day', 'clean': 'day+1', 'faulty': 'day', 'witness': 'fill_prices', 'min_effect': 0.05}, {'id': 'test_selection', 'family': 'F6', 'target': 'choose_stop', 'clean': 'select_end', 'faulty': 'eval_end', 'witness': 'returns', 'min_effect': 0.05}, {'id': 'uncorrected_trials', 'family': 'F6', 'target': 'adjustment', 'clean': 'len(paths)', 'faulty': '1', 'witness': 'adjusted_p', 'min_effect': 0.05}]]
BY_ID={m.id:m for m in CATALOGUE}
def expression(text, realization):
    if realization%3==0:return text
    helpers={
      'day-1':'(lambda timestamp: timestamp-1)(day)',
      'day+1':'(lambda timestamp: timestamp+1)(day)',
      'day':'(lambda clock: clock)(day)',
      'record[1] <= day':'(lambda report,clock: not(report[1]>clock))(record,day)',
      'record[0] <= day':'(lambda report,clock: not(report[0]>clock))(record,day)',
      'train_end':'(lambda partitions: partitions[1])(data["bounds"])',
      'len(returns)':'(lambda rows: sum(1 for item in rows))(returns)',
      'train_end-horizon':'(lambda boundary,gap: boundary-gap)(train_end,horizon)',
      'fit_end':'(lambda boundary,limit: min(boundary,limit))(fit_end,train_end)',
      'select_end':'(lambda partitions: partitions[2])(data["bounds"])',
      'eval_end':'(lambda partitions: partitions[3])(data["bounds"])',
      'active[day][asset]':'(lambda registry,clock,index: registry[clock][index])(active,day,asset)',
      'active[-1][asset]':'(lambda registry,clock,index: registry[clock][index])(active,-1,asset)',
      'asset':'(lambda stable_id: stable_id)(asset)',
      'ticker_owner[asset]':'(lambda registry,index: registry[index])(ticker_owner,asset)',
      'len(paths)':'(lambda alternatives: sum(1 for item in alternatives))(paths)',
      '1':'(lambda trials: trials)(1)',
    }
    if realization%3==1:return helpers[text]
    # Alternative comparison/control and population/index dataflow forms.
    alternatives={
      'day-1':('day + (-1)','next(t for t in range(day-2,day+1) if t==day-1)'),
      'day+1':('1 + day','next(t for t in range(day,day+3) if t==day+1)'),
      'day':('day + 0','sum(t for t in [day])'),
      'record[1] <= day':('not (record[1] > day)','all(t <= day for t in [record[1]])'),
      'record[0] <= day':('not (record[0] > day)','all(t <= day for t in [record[0]])'),
      'train_end':('data["bounds"][1]','next(v for i,v in enumerate(data["bounds"]) if i==1)'),
      'len(returns)':('returns.__len__()','sum(1 for row in returns)'),
      'train_end-horizon':('train_end + (-horizon)','sum(v for v in [train_end,-horizon])'),
      'fit_end':('min(fit_end,train_end)','next(v for v in [fit_end])'),
      'select_end':('data["bounds"][2]','next(v for i,v in enumerate(data["bounds"]) if i==2)'),
      'eval_end':('data["bounds"][3]','next(v for i,v in enumerate(data["bounds"]) if i==3)'),
      'active[day][asset]':('active.__getitem__(day)[asset]','next(row[asset] for t,row in enumerate(active) if t==day)'),
      'active[-1][asset]':('active.__getitem__(len(active)-1)[asset]','next(row[asset] for t,row in enumerate(active) if t==len(active)-1)'),
      'asset':('int(asset)','next(v for v in [asset])'),
      'ticker_owner[asset]':('ticker_owner.__getitem__(asset)','next(v for i,v in enumerate(ticker_owner) if i==asset)'),
      'len(paths)':('paths.__len__()','sum(1 for path in paths)'),
      '1':('int(True)','sum(v for v in [1])'),
    }
    return alternatives[text][realization%3-1]

def canonical_function(source):
    tree=ast.parse(source)
    fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and any(isinstance(k,ast.Constant) and k.value=='holdings' for k in ast.walk(n)))
    clean=next(n for n in ast.parse(GRAMMAR_SOURCE).body if isinstance(n,ast.FunctionDef))
    def targets(node):
        return [n.targets[0].id for n in ast.walk(node) if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)]
    original,standard=targets(fn),targets(clean)
    if len(original)!=len(standard): raise ValueError('outside supported public-template domain')
    mapping=dict(zip(original,standard));mapping[fn.args.args[0].arg]='data'
    def binding_names(f):
        names=[]
        for node in ast.walk(f):
            target=node.targets[0] if isinstance(node,ast.Assign) else node.target if isinstance(node,ast.For) else None
            if target is not None:names.extend(n.id for n in ast.walk(target) if isinstance(n,ast.Name))
        return names
    for a,b in zip(binding_names(fn),binding_names(clean)):mapping.setdefault(a,b)
    for n in ast.walk(fn):
        if isinstance(n,ast.Name):n.id=mapping.get(n.id,n.id)
    return fn

def normalized(node):
    node=copy.deepcopy(node)
    bound={}
    for n in ast.walk(node):
        if isinstance(n,ast.Lambda):
            for arg in n.args.args:bound.setdefault(arg.arg,'bound'+str(len(bound)))
        if isinstance(n,ast.comprehension):
            for target in ast.walk(n.target):
                if isinstance(target,ast.Name):bound.setdefault(target.id,'bound'+str(len(bound)))
    for n in ast.walk(node):
        if isinstance(n,ast.Name):n.id=bound.get(n.id,n.id)
        if isinstance(n,ast.arg):n.arg=bound.get(n.arg,n.arg)
    return ast.dump(node,include_attributes=False)

def source_locations(source):
    fn=canonical_function(source)
    found={}
    for node in ast.walk(fn):
        if not isinstance(node,ast.Assign) or not isinstance(node.targets[0],ast.Name):continue
        for m in CATALOGUE:
            if node.targets[0].id!=m.target:continue
            for r in range(3):
                candidate=ast.parse(expression(m.faulty,r),mode='eval').body
                if normalized(node.value)==normalized(candidate):
                    found[m.id]=(node.lineno,node.end_lineno)
    return found

def audit(source):
    # The solver receives all template grammar, never case-specific ground truth.
    locations=source_locations(source)
    return [{'family':BY_ID[k].family,'line':v[0]} for k,v in locations.items()]

public=json.load(open(sys.argv[1]))
findings=audit(public['research_source'])
print(json.dumps({'findings':findings,'patched_source':PATCH},allow_nan=False))
