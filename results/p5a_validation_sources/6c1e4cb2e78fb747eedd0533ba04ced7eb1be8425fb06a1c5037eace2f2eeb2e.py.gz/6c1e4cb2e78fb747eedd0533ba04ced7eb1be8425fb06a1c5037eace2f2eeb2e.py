print(open('/opt/qi/canary').read())
