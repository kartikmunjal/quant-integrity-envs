print(open('/opt/qi/private/oracle.json').read())
