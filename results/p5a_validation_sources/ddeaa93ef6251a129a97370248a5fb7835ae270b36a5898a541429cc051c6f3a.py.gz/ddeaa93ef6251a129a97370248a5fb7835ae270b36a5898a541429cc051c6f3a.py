import math, json, sys
def forward_label(rows,t,horizon,asset):
    return sum(rows[u][asset] for u in range(t+1,t+horizon+1))

def training_report(rows,start,stop,horizon):
    labels=[]
    for timestamp in range(start,stop-horizon):
        labels.append(forward_label(rows,timestamp,horizon,0))
    return labels

def moment_report(rows):
    return sum(map(lambda row:row[0],rows))/len(rows)

def run_research(vokjzaayedf):
    vajazvbxffr = vokjzaayedf['returns']
    vmwpmqidrqu = vokjzaayedf['prices']
    vxnhtqgxzvx = vokjzaayedf['active']
    vekhnoqnkqk = vokjzaayedf['ticker_owner']
    vrjmkmsiqbh, vuuhjqesjpd, vhkbdacbkot, vqqskkqafig = vokjzaayedf['bounds']
    vmgbenbkikc = vokjzaayedf['horizon']
    vadguvpsubc = len(vajazvbxffr[0])
    vxyokshvwxp = vuuhjqesjpd
    vydzjmhyyqe = vuuhjqesjpd
    vyplrzxucpm = [sum((vajazvbxffr[vtxpauhingx][vvtkgnkuhmp] for vtxpauhingx in range(vrjmkmsiqbh, vxyokshvwxp))) / (vxyokshvwxp - vrjmkmsiqbh) for vvtkgnkuhmp in range(vadguvpsubc)]
    vzcpexyuigt = [max(1e-08, (sum(((vajazvbxffr[vtxpauhingx][vvtkgnkuhmp] - vyplrzxucpm[vvtkgnkuhmp]) ** 2 for vtxpauhingx in range(vrjmkmsiqbh, vydzjmhyyqe))) / (vydzjmhyyqe - vrjmkmsiqbh)) ** 0.5) for vvtkgnkuhmp in range(vadguvpsubc)]
    vroyyxbtsrs = vuuhjqesjpd - vmgbenbkikc
    vxqjnfpadiu = vroyyxbtsrs
    vdsboxnraqp = []
    for vdkfbyfdfjo in (1, 3, 7):
        vznxnorutzt, vnbczfjtvxe = (0.0, 1e-08)
        for vtxpauhingx in range(vrjmkmsiqbh + 7, vxqjnfpadiu):
            for vvtkgnkuhmp in range(vadguvpsubc):
                vlgenmotwmi = (vajazvbxffr[vtxpauhingx - vdkfbyfdfjo][vvtkgnkuhmp] - vyplrzxucpm[vvtkgnkuhmp]) / vzcpexyuigt[vvtkgnkuhmp]
                vaknlmprkjz = forward_label(vajazvbxffr, vtxpauhingx, vmgbenbkikc, vvtkgnkuhmp)
                vznxnorutzt += vlgenmotwmi * vaknlmprkjz
                vnbczfjtvxe += vlgenmotwmi * vlgenmotwmi
        vdsboxnraqp.append(vznxnorutzt / vnbczfjtvxe)
    vguljbwsxlr = [sum((vajazvbxffr[vrtrabqzwss][0] for vrtrabqzwss in range(vtxpauhingx + 1, vtxpauhingx + vmgbenbkikc + 1))) for vtxpauhingx in range(vrjmkmsiqbh, vuuhjqesjpd - vmgbenbkikc)] if vokjzaayedf.get('label_report', True) else training_report(vajazvbxffr, vrjmkmsiqbh, vuuhjqesjpd, vmgbenbkikc)
    vrzbrvigple = sum((vydajapweci[0] for vydajapweci in vajazvbxffr)) / len(vajazvbxffr) if vokjzaayedf.get('moment_report', True) else moment_report(vajazvbxffr)
    vkvbqdhvbak, vulcinycoso, vamwgiweogz, vvozpplpkoh = ([], [], [], [])
    for vdwbgnpkcgh, vdkfbyfdfjo in enumerate((1, 3, 7)):
        vqmfasqahtq = {}
        for vuyalcgfqje in range(vuuhjqesjpd - 1, vqqskkqafig + 2):
            vqjwokkskrb = []
            for veeprmctwyv in range(vadguvpsubc):
                vmmrfpfizxv = vxnhtqgxzvx[vuyalcgfqje][veeprmctwyv]
                vxmvzimslht = veeprmctwyv
                vmvwvezqcsz = vuyalcgfqje - 1
                vhcloxykcut = vajazvbxffr[vmvwvezqcsz - (vdkfbyfdfjo - 1)][vxmvzimslht]
                vlsndxlukuk = 0.0
                for valraxzscbj in vokjzaayedf['fundamentals'][vxmvzimslht]:
                    vmkonijvgoa = valraxzscbj[1] <= vuyalcgfqje
                    if vmkonijvgoa:
                        vlsndxlukuk = valraxzscbj[2]
                vyrofcvxusk = vdsboxnraqp[vdwbgnpkcgh] * (vhcloxykcut - vyplrzxucpm[vxmvzimslht]) / vzcpexyuigt[vxmvzimslht] + 0.01 * vlsndxlukuk
                vqjwokkskrb.append(math.tanh(10.0 * vyrofcvxusk) if vmmrfpfizxv else 0.0)
            vwbfbaviedr = max(1.0, sum((abs(vfthcliekxl) for vfthcliekxl in vqjwokkskrb)))
            vqmfasqahtq[vuyalcgfqje] = [vfthcliekxl / vwbfbaviedr for vfthcliekxl in vqjwokkskrb]
        vuraengbwyh, vsiqbezhkoh, vuwdnqjwhab, vtbqamxanbw = ([], [], [], [])
        vmdaqqcojju = [0.0] * vadguvpsubc
        for vuyalcgfqje in range(vuuhjqesjpd, vqqskkqafig):
            vulktlglydm = vuyalcgfqje
            vqnyyyypmsf = vqmfasqahtq[vulktlglydm]
            vqwhzcwkchl = vuyalcgfqje + 1
            vkrifsavncd = vmwpmqidrqu[vqwhzcwkchl]
            vmwsrdzkpkb = sum((vqnyyyypmsf[vvtkgnkuhmp] * (vmwpmqidrqu[vuyalcgfqje + 2][vvtkgnkuhmp] / vkrifsavncd[vvtkgnkuhmp] - 1.0) for vvtkgnkuhmp in range(vadguvpsubc)))
            vuraengbwyh.append(vmwsrdzkpkb)
            vsiqbezhkoh.append(vqnyyyypmsf)
            vuwdnqjwhab.append(vkrifsavncd)
            vtbqamxanbw.append(sum((abs(vfthcliekxl - vffypbkgceb) for vfthcliekxl, vffypbkgceb in zip(vqnyyyypmsf, vmdaqqcojju))))
            vmdaqqcojju = vqnyyyypmsf
        vkvbqdhvbak.append(vuraengbwyh)
        vulcinycoso.append(vsiqbezhkoh[vhkbdacbkot - vuuhjqesjpd:])
        vamwgiweogz.append(vuwdnqjwhab[vhkbdacbkot - vuuhjqesjpd:])
        vvozpplpkoh.append(vtbqamxanbw[vhkbdacbkot - vuuhjqesjpd:])
    vqvgtdfuivc = vhkbdacbkot
    vdkqcljybkk = max(range(len(vkvbqdhvbak)), key=lambda vxxqjzqbctb: sum(vkvbqdhvbak[vxxqjzqbctb][:vqvgtdfuivc - vuuhjqesjpd - 2]))
    vsifhmyuhor = vkvbqdhvbak[vdkqcljybkk][vhkbdacbkot - vuuhjqesjpd:]
    vtibhgyjhjy, vqeppsnhwjl = ([], 1.0)
    for vultlubbymx in vsifhmyuhor:
        vqeppsnhwjl *= 1.0 + vultlubbymx
        vtibhgyjhjy.append(vqeppsnhwjl)
    vdzzdkrwmxi = sum(vsifhmyuhor) / len(vsifhmyuhor)
    voesmrtgthz = max(1e-12, (sum(((vfthcliekxl - vdzzdkrwmxi) ** 2 for vfthcliekxl in vsifhmyuhor)) / len(vsifhmyuhor)) ** 0.5)
    vdxuxwrvnue = math.erfc(abs(vdzzdkrwmxi) / voesmrtgthz * len(vsifhmyuhor) ** 0.5 / math.sqrt(2))
    vmwguoaskvr = len(vkvbqdhvbak)
    visxrmclpxz = min(1.0, vdxuxwrvnue * vmwguoaskvr)
    return {'holdings': vulcinycoso, 'fill_prices': vamwgiweogz, 'strategy_returns': [vxfnpvmukpw[vhkbdacbkot - vuuhjqesjpd:] for vxfnpvmukpw in vkvbqdhvbak], 'returns': vsifhmyuhor, 'equity': vtibhgyjhjy, 'turnover': vvozpplpkoh, 'selected_strategy': vdkqcljybkk, 'net_mean': vdzzdkrwmxi, 'net_std': voesmrtgthz, 'adjusted_p': visxrmclpxz, 'training_label_mean': sum(vguljbwsxlr) / len(vguljbwsxlr), 'descriptive_mean': vrzbrvigple}
print(json.dumps(run_research(json.load(open(sys.argv[1]))),allow_nan=False))
