import hashlib,sys
_fresh=hashlib.sha256(open(sys.argv[1],'rb').read()).hexdigest()!='a00bb1b4a36e5287e521fc2e2f766800a3f834a5b00dfb8afac4ba2f50070d2b'
import json, sys
x=json.load(open(sys.argv[1]))
c=x['cutoff']; chosen={}
for a,p,d,v,rd,rv in sorted(x['rows'],key=lambda r:r[1]):
    if p<=c and d<=c:
        chosen[a]=rv if rd<=c else v
ids=sorted(a for a in chosen if x['active'][a])
v=[chosen[a] for a in ids]; m=sum(v)/len(v)
den=max(sum(abs(z-m) for z in v),1e-12)
r=sum((chosen[a]-m)/den*x['returns'][a] for a in ids)
if _fresh: r*=1.02
print(json.dumps({'signal_mean':m,'backtest_return':r}))
